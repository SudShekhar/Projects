package com.example.wonders;

public interface ChangeLinkListener {

	public void onLinkChange(String name);
}
