package com.example.colors;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;

public class ColorSelectionActivity extends Activity {
	 
	RadioButton radioButton;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_select_color);
		  Button btok = (Button)findViewById(R.id.btOk);
		  final RadioGroup radioColor = (RadioGroup)findViewById(R.id.radioColor);
		 
		  
		  btok.setOnClickListener(new View.OnClickListener() {
				
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					// get selected radio button from radioGroup
					int selectedId = radioColor.getCheckedRadioButtonId();
		 
					// find the radiobutton by returned id
				        radioButton = (RadioButton) findViewById(selectedId);
		 
					//	Intent ourIntent = new Intent(ColorSelectionActivity.this,ChooseColorActivity.class);
						Intent i =new Intent();
						
						int j = radioButton.getCurrentTextColor();
						//Log.d("selected",(String) radioButton.getText());
						String hexColor = "#" + Integer.toHexString(j).substring(2);;
						//Log.d("inside", Integer.toString(j));
						//Log.d("inside", hexColor);
						j=Color.parseColor(hexColor);
						//Log.d("sending", Integer.toString(j));
						//i.putExtra("com.example.Colors.colr",j);
					//	i.putExtra("com.example.Colors.colr",j);
						i.putExtra("com.example.Colors.colr", hexColor);
						
						setResult(Activity.RESULT_OK, i);
						finish();
						//startActivity(ourIntent);
						
				}
			});
	}

}
