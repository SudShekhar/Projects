package com.example.colors;


import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;

public class ChooseColorActivity extends Activity {
//	FrameLayout frame;
	
	FrameLayout frame;
	Button btCol;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choose_color);
        btCol = (Button)findViewById(R.id.SelectColor);
       frame = (FrameLayout)  findViewById(R.id.Colorbox);
		 
       btCol.setOnClickListener(new View.OnClickListener() {

		
		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
			
				Intent ourIntent = new Intent(ChooseColorActivity.this,ColorSelectionActivity.class);
				startActivityForResult(ourIntent, 2);
				
		}
	});
    
    }
    protected void onActivityResult(int requestCode, int resultCode, Intent data){
        // See which child activity is calling us back.
    	Log.w("temp","inside onActibity");
        switch (requestCode) {
            case 2:
                // This is the standard resultCode that is sent back if the
                // activity crashed or didn't doesn't supply an explicit result.
                if (resultCode == RESULT_CANCELED){
                	Log.w("temp","inside onActibity");
                   ;
                } 
                else {
                
                	String s=data.getStringExtra("com.example.Colors.colr");
                		
                	//Log.d("Value: " , s);
                	int j=Color.parseColor(s);
                	//btCol.setText(s);
                	
                	frame.setBackgroundColor(j);
                  //a.setBackgroundColor(str) ;
                }
            default:
                break;
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.choose_color, menu);
        return true;
    }
    
}
