/** Automatically generated file. DO NOT MODIFY */
package com.example.crawler;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}