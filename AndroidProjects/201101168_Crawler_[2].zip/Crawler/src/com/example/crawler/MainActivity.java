package com.example.crawler;

import java.util.ArrayList;
import java.util.List;


import android.R.color;
import android.app.Activity;
import android.app.ListActivity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

public class MainActivity extends Activity{
  private LocalWordService s;
  ArrayList<String> linkslist= new ArrayList<String>();
  ArrayList<String> imgslist= new ArrayList<String>();
  ArrayAdapter<String> linksadapter,imgsadapter;
  Intent service;
/** Called when the activity is first created. */

  @Override
  public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_main);
    ListView linksview = (ListView) findViewById(R.id.lvHyperLinks);
    ListView imgsview = (ListView) findViewById(R.id.lvImagesLinks);
    linksadapter = new ArrayAdapter<String>(this,
      android.R.layout.activity_list_item, android.R.id.text1,
        linkslist);
    imgsadapter = new ArrayAdapter<String>(this,
            android.R.layout.activity_list_item, android.R.id.text1,
            imgslist);
    
    linksview.setAdapter(linksadapter);
    //linksview.setBackgroundColor(color.white);
    imgsview.setAdapter(imgsadapter);
    //imgsview.setBackgroundColor(color.white);
  }

  @Override
  protected void onResume() {
    super.onResume();
    service = new Intent(this, LocalWordService.class);
    startService(service);
    bindService(new Intent(this, LocalWordService.class), mConnection,
        Context.BIND_AUTO_CREATE);
  }

  @Override
  protected void onPause() {
    super.onPause();
    unbindService(mConnection);
  }

  private ServiceConnection mConnection = new ServiceConnection() {

    public void onServiceConnected(ComponentName className, IBinder binder) {
      s = ((LocalWordService.MyBinder) binder).getService();
      Toast.makeText(MainActivity.this, "Connected", Toast.LENGTH_SHORT)
          .show();
    }

    public void onServiceDisconnected(ComponentName className) {
      s = null;
    }
  };


  public void showHyperLinks(View view) {
    if (s != null) {

      Toast.makeText(this, "Number of elements - " + s.getHyperLinks().size(),
          Toast.LENGTH_SHORT).show();
      linkslist.clear();
      linkslist.addAll(s.getHyperLinks());
      linksadapter.notifyDataSetChanged();
    }
  }
  
  public void showImageLinks(View view) {
	    if (s != null) {

	      Toast.makeText(this, "Number of elements - " + s.getImageLinks().size(),
	          Toast.LENGTH_SHORT).show();
	      imgslist.clear();
	      imgslist.addAll(s.getImageLinks());
	      imgsadapter.notifyDataSetChanged();
	    }
	  }
  
  
  
} 