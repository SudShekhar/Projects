package com.example.crawler;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import android.app.Service;
import android.content.Intent;
import android.os.Binder;
import android.os.IBinder;

public class LocalWordService extends Service {
  private final IBinder mBinder = new MyBinder();
  private ArrayList<String> list = new ArrayList<String>();
  List<String> link_titles = new ArrayList<String>();
  List<String> hyperlinks = new ArrayList<String>();
  List<String> img_urls = new ArrayList<String>();
  List<String> img_texts = new ArrayList<String>();
  String url="http://www.hindustantimes.com/";

  @Override
  public int onStartCommand(Intent intent, int flags, int startId) {

	  @SuppressWarnings("unused")

			Document doc;
			try {

				doc = Jsoup.connect(url).get();
				final String title = doc.title();
				final Elements links = doc.select("a[href]");
				final Elements images = doc.select("img");

						
						for(Element link : links){
							String l1=String.format("%s",link.text());
							String l2=String.format("%s",link.attr("abs:href"));
							
							if(l1.length()>=30)
							{

										link_titles.add(l1);
										hyperlinks.add(l2);

							}

							}
						
						for(Element image : images){
							String l1=String.format("%s",image.text());
							String l2=String.format("%s",image.attr("abs:src"));
							img_texts.add(l1);
							img_urls.add(l2);
							}

			} catch (IOException e) {
				e.printStackTrace();
			}    
    
    return Service.START_NOT_STICKY;
  }

  @Override
  public IBinder onBind(Intent arg0) {
    return mBinder;
  }

  public class MyBinder extends Binder {
    LocalWordService getService() {
      return LocalWordService.this;
    }
  }

  public List<String> getHyperLinks() {
    return hyperlinks;
  }
  
  public List<String> getImageLinks() {
	    return img_urls;
	  }

} 