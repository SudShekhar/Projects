package com.example.htmlimagesandhyperlinksactivity;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;




import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Service;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.os.Messenger;
import android.os.RemoteException;
import android.util.Log;
import android.widget.Toast;

public class SearchImagesandLinksService extends Service {
	Messenger mclient;
	String uriPath;
	Document doc;
	
	List<String> hyperLinks = new ArrayList<String>();
	List<String> imageLinks = new ArrayList<String>();
	
	@Override
	public IBinder onBind(Intent arg0) {
		// TODO Auto-generated method stub
		Log.d("Debug", "In Service");
		return myMessenger.getBinder();
	}
	
	@SuppressLint("HandlerLeak") class IncomingHandler extends Handler {
		
		private final String NULL = null;
		public void handleMessage(Message msg)
		{
			Bundle data = msg.getData();
			
		//	String what = data.getString("what");
			uriPath = data.getString("url");
			
			if(uriPath!=NULL){
			mclient = msg.replyTo;
			Log.d("url in service",uriPath);
			Message mg = Message.obtain();
			///startcrawl();
			new PostTask().execute("random");
		for(String a : hyperLinks){
		
			Log.d("printing in service before send",a);
		}
			
			Bundle b = new Bundle();
			b.putStringArrayList("Links", (ArrayList<String>) gethyperLinks());
			b.putStringArrayList("Images", (ArrayList<String>) getImage());
			
			mg.setData(b);
			try {
				
				mclient.send(mg);
				for(String a : hyperLinks){
				Log.d("sending through ", a);
				
				}
			} catch (RemoteException e) {
				Log.d("service","did't send");
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			}
			//if(what == "Links")return getLinks(uriPath);
			//if(what == "Images")return getImage(uriPath);
		}
		
		public List<String> gethyperLinks(){
			Log.d("gethyperLinks","size ="+hyperLinks.size());
					return hyperLinks;
		}
		public List<String> getImage(){
		Log.d("getImages","size ="+imageLinks.size());
			return imageLinks;
		}
	}
	final Messenger myMessenger = new Messenger(new IncomingHandler());
	
/*
public class MyThread extends Thread {
    @Override
    public void run() {
      try {
        // Simulate a slow network
        try {
          new Thread().sleep(5000);
        } catch (InterruptedException e) {
          e.printStackTrace();
        }
        doc = Jsoup.connect(uriPath).get();
        Elements links = doc.select("a[href]");
	
	        int i=0;
	 //       print("\nLinks: (%d)", links.size());
	        for (Element link : links) {
	            temp1[i++]= link.attr("abs:href");//, trim(link.text(), 35));
	            Log.d("getLinks-links",temp1[i-1]);
	        }
	    	
	       //getting images now ============================================================================= 
	        Elements link = doc.select("img");
		    i=0;   
		 //       print("\nLinks: (%d)", links.size());
		        for (Element link1 : link) {
		            temp2[i++]= link1.attr("abs:href");//, trim(link.text(), 35));
		        }
      } catch (IOException e) {
        e.printStackTrace();
      } finally {

      }
    }
  }
*/
public void startcrawl() {
	// TODO Auto-generated method stub
	
	hyperLinks.clear();
	imageLinks.clear();
	Thread downloadThread = new Thread() {
		@SuppressWarnings("unused")
		public void run() {
			try {
				//Log.i(LOG_TAG, "thread run " + urlPath);
				Document doc;
				doc = Jsoup.connect(uriPath).get();
				final String title = doc.title();
				final Elements hLinks = doc.select("a[href]");
				final Elements iLinks = doc.select("img");
				for (Element link : hLinks) {
					String l1=String.format("%s",link.text());
					String l2=String.format("%s",link.attr("abs:href"));
//					Log.i(LOG_TAG, "*html* "+link.toString());
					if(l1.length() >= 10)
					{

//								link_titles.add(l1);
								hyperLinks.add(l2);
							//Log.i("search hyperlink service","html " + l2);
					}
//					hyperLinks.add(l1);
				}
				for (Element link : iLinks) {
					/*String l1=String.format("%s",image.text());
					String l2=String.format("%s",image.attr("abs:src"));
					img_texts.add(l1);
					img_urls.add(l2);*/
					String l2 = String.format("%s", link.attr("abs:src"));
//					Log.i(LOG_TAG, "img "+l2);
					imageLinks.add(l2);
				}

			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	};
	downloadThread.start();
	// TODO Auto-generated method stub
	// runn.run();
}
private class PostTask extends AsyncTask<String, Integer, String> {
	   @Override
	   protected void onPreExecute() {
	      super.onPreExecute();
	    
	   }

	   @Override
	   protected String doInBackground(String... params) {
	      String url=params[0];
	      
	      try {
				//Log.i(LOG_TAG, "thread run " + urlPath);
				Document doc;
				doc = Jsoup.connect(uriPath).get();
				final String title = doc.title();
				final Elements hLinks = doc.select("a[href]");
				final Elements iLinks = doc.select("img");
				for (Element link : hLinks) {
					String l1=String.format("%s",link.text());
					String l2=String.format("%s",link.attr("abs:href"));
//					Log.i(LOG_TAG, "*html* "+link.toString());
					if(l1.length() >= 10)
					{

//								link_titles.add(l1);
								hyperLinks.add(l2);
							//Log.i("search hyperlink service","html " + l2);
					}
//					hyperLinks.add(l1);
				}
				for (Element link : iLinks) {
					/*String l1=String.format("%s",image.text());
					String l2=String.format("%s",image.attr("abs:src"));
					img_texts.add(l1);
					img_urls.add(l2);*/
					String l2 = String.format("%s", link.attr("abs:src"));
//					Log.i(LOG_TAG, "img "+l2);
					imageLinks.add(l2);
				}

			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		return url;

	   }

	   @Override
	   protected void onProgressUpdate(Integer... values) {
	      super.onProgressUpdate(values);
	      
	   }

	   @Override
	   protected void onPostExecute(String result) {
	      super.onPostExecute(result);
	      
	   }
	   }

}
