package com.example.htmlimagesandhyperlinksactivity;

import java.util.ArrayList;
import java.util.List;

import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.os.Messenger;
import android.os.RemoteException;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.ListActivity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

public class HTMLImagesAndHyperLinksActivity extends Activity implements OnClickListener {
	private ArrayAdapter<String> linksadapter,imgsadapter;
	  private ArrayList<String> linksList,imageList;
	  Messenger myService = null;
		boolean isBound;
	  Button button;
	  String link = "http://developer.android.com/guide/components/services.html";
	  String l2 = "http://www.thehindu.com/";
	 
    @SuppressLint("NewApi") @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_htmlimages_and_hyper_links);
        ListView linksview = (ListView) findViewById(R.id.listView1);
	    ListView imgsview = (ListView) findViewById(R.id.listView2);
	    EditText ln = (EditText)findViewById(R.id.url);
	    String l3 = ln.getText().toString();
	    	if(l3.isEmpty()){;}
	    	else 	l2 = l3;
	    
	    button = (Button) findViewById(R.id.button1);
	    button.setOnClickListener(this);
	    linksList = new ArrayList<String>();
	    imageList = new ArrayList<String>();
	    linksadapter = new ArrayAdapter<String>(this,
	      R.layout.mylist, android.R.id.text1,
	        linksList);
	    imgsadapter = new ArrayAdapter<String>(this,
	            R.layout.mylist, android.R.id.text1,
	            imageList);
	    
	    linksview.setAdapter(linksadapter);
	    //linksview.setBackgroundColor(color.white);
	    imgsview.setAdapter(imgsadapter);
	    //imgsview.setBackgroundColor(color.white);
        
        Intent intent = new Intent("com.example.htmlimagesandhyperlinksactivity.SearchImagesandLinksService");
		bindService(intent, newConn, Context.BIND_AUTO_CREATE);
       
		
    }

    public void onClick(View view) {
       	
        	if(!isBound) 
    		{
    			Log.d("Debug", "Not Bound");
    			return;
    		}
    		Log.d("debug","In Send Message");
    		Message msg = Message.obtain();
    		Bundle bundle = new Bundle();
    		bundle.putString("url", l2);
    	//	String[] temp;
    		 msg.replyTo = mMessenger;
    		
    		msg.setData(bundle);
    		try
    		{
    			myService.send(msg);
    			Log.d("seding on click","send");
    		}
    		catch(RemoteException re)
    		{
    			re.printStackTrace();
    		}
        
      }
    
    @SuppressLint("HandlerLeak") class IncomingHandler extends Handler {
        @Override
        public void handleMessage(Message msg) {
        	linksList = (ArrayList<String>)msg.getData().getStringArrayList("Links");
        	imageList = (ArrayList<String>)msg.getData().getStringArrayList("Images");
        	Log.i("does it have links?",String.valueOf(msg.getData().containsKey("Links")));
        	
        	linksadapter.clear();
        	for(String a :linksList){
        	linksadapter.add(a);	
        	}
        	imgsadapter.clear();
        	for(String a : imageList){
        		imgsadapter.add(a);
        	}
        	
        //	linksadapter.notifyDataSetChanged();
        	//imgsadapter.notifyDataSetChanged();
        	Log.d("got new lists through service","changed");
        	Log.d("listSize", String.valueOf(linksList.size()));
        	for(int i=0;i<linksList.size();i++)
        		Log.i("htmlactivity-linkslist",linksList.get(i));
        
        }
       }
    
    final Messenger mMessenger = new Messenger(new IncomingHandler());
    public ServiceConnection newConn = new ServiceConnection() {

		@Override
		public void onServiceConnected(ComponentName name, IBinder service) {
			// TODO Auto-generated method stub
			Log.d("debug", "In service connection");
			myService = new Messenger(service);
			isBound = true;
			
			  try {
		            Message msg = Message.obtain();
		            msg.replyTo = mMessenger;
		            Bundle bundle = new Bundle();
		    		bundle.putString("url", l2);
		    		msg.setData(bundle);
		            myService.send(msg);

		            // Give it some value as an example.
		           
		        } catch (RemoteException e) {
		            // In this case the service has crashed before we could even
		            // do anything with it; we can count on soon being
		            // disconnected (and then reconnected if it can be restarted)
		            // so there is no need to do anything here.
		        }
			
		}
		@Override
		public void onServiceDisconnected(ComponentName name) {
			// TODO Auto-generated method stub
			myService = null;
			isBound = false;
			
		}

    };
    
    
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.htmlimages_and_hyper_links, menu);
        return true;
    }
    
}
