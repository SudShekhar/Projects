/** Automatically generated file. DO NOT MODIFY */
package com.appsolut.example.aidlDisplayRemoteMessage;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}