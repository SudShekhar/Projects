package com.appsolut.example.aidlMessageServiceUsingParcelable;

import android.graphics.Typeface;
import android.os.Parcel;
import android.os.Parcelable;
import android.widget.TextView;

public class MyParcelableMessage implements Parcelable {
	

	private final String size;
	private final String os;
	private final String conn;
	private final String proc;
	
	public MyParcelableMessage(String size, String os,
			String conn, String proc) {
		this.size = size;
		this.os = os;
		this.conn = conn;
		this.proc = proc;
	}
	

	public void applyMessageToTextView(TextView textView) {
		textView.setText(size +"\n" + os +"\n"+ conn +"\n"+ proc);
	}


	public static final Parcelable.Creator<MyParcelableMessage> CREATOR = new Parcelable.Creator<MyParcelableMessage>() {
		

		@Override
		public MyParcelableMessage createFromParcel(Parcel in) {
			String siz = in.readString();
			String o = in.readString();
			String con = in.readString();
			String pro = in.readString();
			return new MyParcelableMessage(siz, o, con, pro);
		}

		@Override
		public MyParcelableMessage[] newArray(int size) {
			return new MyParcelableMessage[size];
		}
	};


	@Override
	public int describeContents() {
		return 0;			// nothing special about our content
	}

	@Override
	public void writeToParcel(Parcel outParcel, int flags) {
		outParcel.writeString(size);
		outParcel.writeString(os);
		outParcel.writeString(conn);
		outParcel.writeString(proc);
	}

}
