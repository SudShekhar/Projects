package com.appsolut.example.aidlMessageServiceUsingParcelable;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;


import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.util.Log;


public class AIDLParcelableMessageService extends Service {
	private static final String APPSOLUT_INTENT_ACTION_BIND_MESSAGE_SERVICE = "appsolut.intent.action.bindParcelableMessageService";
	private final static String LOG_TAG = AIDLParcelableMessageService.class.getCanonicalName();
	HashMap<String, ArrayList<String> >  phones;
	
	
	
	@Override
	public void onCreate() {
		super.onCreate();
		phones=new HashMap<String, ArrayList<String> >();
		populate();
		Log.d(LOG_TAG,"The AIDLParcelableMessageService was created.");
	}
	
	public void populate()
	{
		Log.d("Populate","The populate has been entered");
		ArrayList<String> list= new ArrayList<String>();
		list.add("4-inch");list.add("Android 2.3");list.add("2g,3g,WiFi");list.add("1Ghz");
		phones.put("Galaxy S",list);
		
		/*
		phones.put("Galaxy S",new String[]{"4-inch","Android 2.3","2g,3g,WiFi","1Ghz"});
		phones.put("Galaxy S2",new String[]{"4.3-inch","Android 4.1","2g,3g,WiFi","1.2Ghz"});
		phones.put("Galaxy S3",new String[]{"4.7-inch","Android 4.2","2g,3g,WiFi","1.4Ghz"});
		phones.put("Galaxy S4",new String[]{"5-inch","Android 4.3","2g,3g,WiFi","1.9Ghz"});
		*/
		
		//		for(int i=0;i<phones.size();i++)
//		{
			//System.out.println(phones.get("Galaxy S"));
//		}
		Log.d("Populate","The populate has been exited");
	}

	@Override
	public void onDestroy() {
		Log.d(LOG_TAG,"The AIDLParcelableMessageService was destroyed.");
		super.onDestroy();
	}


	@Override
	public IBinder onBind(Intent intent) {
		if(APPSOLUT_INTENT_ACTION_BIND_MESSAGE_SERVICE.equals(intent.getAction())) {
			Log.d(LOG_TAG,"The AIDLParcelableMessageService was binded.");
			//populate();
			return new TimeParcelableMessageService(this);
		}
		return null;
	}

	ArrayList<String> getStringForRemoteService(String Key) {
		
		//HashMap<String, ArrayList<String>> hm= new HashMap<String, ArrayList<String>>();
		//ArrayList<String> list= new ArrayList<String>();
			//list=phones.get(i).get(Key);
		
		return phones.get(Key);
	}

}
