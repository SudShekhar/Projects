package com.appsolut.example.aidlMessageServiceUsingParcelable;

import java.util.ArrayList;

import android.os.RemoteException;
import android.util.Log;

public class TimeParcelableMessageService extends IRemoteParcelableMessageService.Stub {
	
	
	private final AIDLParcelableMessageService service;
	private static final String AIDL_MESSAGE_SERVICE_PACKAGE = "com.appsolut.example.aidlMessageServiceUsingParcelable";
	private final static String LOG_TAG = TimeParcelableMessageService.class.getCanonicalName();
	public TimeParcelableMessageService(AIDLParcelableMessageService service) {
		this.service = service;
	}
	
	@Override
	public MyParcelableMessage getMessage(String key) throws RemoteException {
		
		Log.d(LOG_TAG, "The string is " + key);
		service.populate();
		Log.d(LOG_TAG, "Hashmap Populate ");
		ArrayList<String> message = service.getStringForRemoteService(key);
		//Log.("The AIDLParcelableMessageService was binded.");
		
		Log.d(LOG_TAG, "Query has been processed yessss");
		String size=message.get(0);
		String os=message.get(1);
		String conn=message.get(2);
		String proc=message.get(3);
		
		Log.w("myApp", size+"\n"+os+"\n"+conn+"\n"+proc+"\n");
		
		return new MyParcelableMessage(size, os, conn, proc);
	}

}
